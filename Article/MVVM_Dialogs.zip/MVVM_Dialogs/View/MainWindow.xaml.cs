﻿using System.Windows;

namespace MVVM_Dialogs.View
{
	/// <summary>
	/// Main window of the application.
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
