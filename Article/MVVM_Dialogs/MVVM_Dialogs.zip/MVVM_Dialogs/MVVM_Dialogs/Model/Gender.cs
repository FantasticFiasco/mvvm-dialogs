﻿namespace MVVM_Dialogs.Model
{
	/// <summary>
	/// Describing the gender of a person.
	/// </summary>
	public enum Gender
	{
		Male,
		Female
	}
}
