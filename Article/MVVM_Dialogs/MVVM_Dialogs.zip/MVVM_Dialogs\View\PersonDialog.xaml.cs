﻿using System.Windows;

namespace MVVM_Dialogs.View
{
	/// <summary>
	/// Dialog displaying information about a person.
	/// </summary>
	public partial class PersonDialog : Window
	{
		public PersonDialog()
		{
			InitializeComponent();
		}
	}
}
