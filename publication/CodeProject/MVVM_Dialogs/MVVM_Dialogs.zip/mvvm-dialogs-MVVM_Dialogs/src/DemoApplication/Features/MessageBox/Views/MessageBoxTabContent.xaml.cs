﻿namespace DemoApplication.Features.MessageBox.Views
{
    public partial class MessageBoxTabContent
    {
        public MessageBoxTabContent()
        {
            InitializeComponent();
        }
    }
}