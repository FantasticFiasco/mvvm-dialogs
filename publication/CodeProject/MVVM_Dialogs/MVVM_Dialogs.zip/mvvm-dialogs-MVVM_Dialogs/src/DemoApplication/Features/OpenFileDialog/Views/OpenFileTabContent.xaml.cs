﻿namespace DemoApplication.Features.OpenFileDialog.Views
{
    public partial class OpenFileTabContent
    {
        public OpenFileTabContent()
        {
            InitializeComponent();
        }
    }
}