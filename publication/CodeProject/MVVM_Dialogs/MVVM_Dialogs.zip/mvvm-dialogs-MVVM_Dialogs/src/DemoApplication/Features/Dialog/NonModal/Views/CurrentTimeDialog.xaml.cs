﻿namespace DemoApplication.Features.Dialog.NonModal.Views
{
    public partial class CurrentTimeDialog
    {
        public CurrentTimeDialog()
        {
            InitializeComponent();
        }
    }
}