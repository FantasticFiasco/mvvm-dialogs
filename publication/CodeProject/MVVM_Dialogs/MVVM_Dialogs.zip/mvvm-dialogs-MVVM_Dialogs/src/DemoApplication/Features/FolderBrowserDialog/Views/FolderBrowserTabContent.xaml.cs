﻿namespace DemoApplication.Features.FolderBrowserDialog.Views
{
    public partial class FolderBrowserTabContent
    {
        public FolderBrowserTabContent()
        {
            InitializeComponent();
        }
    }
}