﻿namespace DemoApplication.Features.Dialog.NonModal.Views
{
    public partial class NonModalDialogTabContent
    {
        public NonModalDialogTabContent()
        {
            InitializeComponent();
        }
    }
}