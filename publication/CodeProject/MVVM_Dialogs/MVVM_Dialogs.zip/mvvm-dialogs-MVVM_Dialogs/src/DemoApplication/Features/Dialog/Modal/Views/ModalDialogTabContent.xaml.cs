﻿namespace DemoApplication.Features.Dialog.Modal.Views
{
    public partial class ModalDialogTabContent
    {
        public ModalDialogTabContent()
        {
            InitializeComponent();
        }
    }
}