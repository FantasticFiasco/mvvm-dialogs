﻿namespace DemoApplication.Features.SaveFileDialog.Views
{
    public partial class SaveFileTabContent
    {
        public SaveFileTabContent()
        {
            InitializeComponent();
        }
    }
}